﻿import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import GradientBoostingRegressor 
from sklearn.preprocessing import Imputer as imp



exec_path = os.getcwd()
df = pd.read_csv(os.path.join(exec_path, "fract.csv"))

imputer = imp(missing_values=np.nan, strategy='mean', axis=0)
#               1            2       3        4       5                     
label = ['reservoir_power', 'h', 'proppant', 'up', 'down',
         #     6            7       8         9       10 
         'Half-length', 'Height', 'Width', 'skin', 'Permeability', 
         #      11       12              13
         'pressure', 'Trunk_tilt', 'concentration']
df[label] = imputer.fit_transform(df[label])
print(df)

X = df.iloc[:, [1,2,4,5,9,10,11,12,13]].values
y = df.iloc[:, [6]].values

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size = 0.55,  random_state = 0)

#Для прогноза значения
X_testing = [[15, 5, 2800, 2815, 5, 2, 250, 90, 1200]]

est = 100000

gbrt = GradientBoostingRegressor(loss = 'quantile', learning_rate=0.001, n_estimators=est, 
                                 subsample=0.5, criterion='friedman_mse', min_samples_split=2,
                                 min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=4,
                                 min_impurity_decrease=0.0, min_impurity_split=None, init=None,
                                 random_state=42, max_features=None, alpha=0.58, verbose=0.01, 
                                 max_leaf_nodes=None, warm_start=False, 
                                 validation_fraction=0.001, n_iter_no_change=None, tol=0.1
                                 )
gbrt.fit(X_train, y_train)
errors = [mean_squared_error(y_val, y_pred)
         for y_pred in gbrt.staged_predict(X_val)] 
bst_n_estimators = np.argmin(errors) 
gbrt_best = GradientBoostingRegressor(loss = 'quantile', learning_rate=0.001, n_estimators=bst_n_estimators, 
                                 subsample=0.5, criterion='friedman_mse', min_samples_split=2,
                                 min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=4,
                                 min_impurity_decrease=0.0, min_impurity_split=None, init=None,
                                 random_state=42, max_features=None, alpha=0.58, verbose=0.01, 
                                 max_leaf_nodes=None, warm_start=False, 
                                 validation_fraction=0.001, n_iter_no_change=None, tol=0.1
                                 ) 
gbrt_best.fit(X_train, y_train) 

min_error = np.min(errors)

gbrt = GradientBoostingRegressor(loss = 'quantile', learning_rate=0.001, n_estimators=est, 
                                 subsample=0.5, criterion='friedman_mse', min_samples_split=2,
                                 min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=4,
                                 min_impurity_decrease=0.0, min_impurity_split=None, init=None,
                                 random_state=42, max_features=None, alpha=0.58, verbose=0.01, 
                                 max_leaf_nodes=None, warm_start=False, 
                                 validation_fraction=0.001, n_iter_no_change=None, tol=0.1
                                 )
min_val_error = float("inf")
error_going_up = 0
for n_estimator in range(1, est):
    gbrt.n_estimator = n_estimator
    gbrt.fit(X_train, y_train) 
    y_pred = gbrt.predict(X_val)
    val_error = mean_squared_error(y_val, y_pred)
    if val_error < min_val_error: 
        min_val_error = val_error
        error_going_up = 0
    else:
        error_going_up += 1
        if error_going_up == 5:
            break

plt.figure()
plt.subplot(111)
plt.title("Validation error")
plt.xlabel("Number of trees prediction propant")
plt.ylabel("error")

plt.plot(errors, "b.-")
plt.plot([bst_n_estimators, bst_n_estimators], [0, min_error], "k--")
plt.plot([0, bst_n_estimators], [min_error, min_error], "k--")
plt.plot(bst_n_estimators, min_error, "ko")
plt.text(bst_n_estimators, min_error*1.009, "Minimum", ha="center")
plt.axis([0, bst_n_estimators*2, (min_error*0.95), min_error*1.030])

plt.show()

print('Minimum validation MSE:{}' .format(min_error))
print('Лучшее дерево:{} Всего деревьев:{}'.format(bst_n_estimators, gbrt.n_estimators))

Pred = gbrt.predict(X_testing)
print('Прогнозное значение проппанта:{}'.format(Pred))

file = open("Propant.txt", "w")
file.write(
        repr('Прогнозное значение проппанта:{}, T; Лучшее дерево:{} Всего деревьев:{}; Minimum validation MSE:{}'.format(
                Pred, bst_n_estimators, gbrt.n_estimators, min_error)))
file.close()

